# Menu-Borders
Non JS or JQuery animated menu borders, part of first Modern Developer Hackathon

##Live Demo:https://ericlosorio.github.io/Menu-Borders/borders.html
